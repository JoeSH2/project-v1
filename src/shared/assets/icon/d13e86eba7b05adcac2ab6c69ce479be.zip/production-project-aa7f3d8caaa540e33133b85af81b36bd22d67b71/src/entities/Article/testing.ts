export { articleDetailsReducer } from './model/slice/articleDetailsSlice';
