export enum Currency {
    'RUB' = 'RUB',
    'EUR' = 'EUR',
    'USD' = 'USD',
}
