export { PAGE_ID, Page } from './ui/Page/Page';
