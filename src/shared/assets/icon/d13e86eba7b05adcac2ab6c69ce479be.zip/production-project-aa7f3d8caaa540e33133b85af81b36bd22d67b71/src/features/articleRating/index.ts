export {
    ArticleRatingAsync as ArticleRating,
} from './ui/ArticleRating/ArticleRating.async';
