export interface AddCommentFormSchema {
    text?: string;
    error?: string;
}
