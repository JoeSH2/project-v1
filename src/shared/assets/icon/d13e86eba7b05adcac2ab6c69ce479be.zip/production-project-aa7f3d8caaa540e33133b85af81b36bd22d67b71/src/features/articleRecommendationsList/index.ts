export { ArticleRecommendationsList } from './ui/ArticleRecommendationsList/ArticleRecommendationsList';
