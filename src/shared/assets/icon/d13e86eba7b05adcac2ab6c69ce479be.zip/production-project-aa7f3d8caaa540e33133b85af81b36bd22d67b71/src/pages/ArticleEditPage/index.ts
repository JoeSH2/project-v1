export {
    ArticleEditPageAsync as ArticleEditPage,
} from './ui/ArticleEditPage/ArticleEditPage.async';
