export { articleDetailsPageReducer } from './model/slices';
